#!/bin/bash

source /envsetup.sh

# Execute the main container command
exec "$@"