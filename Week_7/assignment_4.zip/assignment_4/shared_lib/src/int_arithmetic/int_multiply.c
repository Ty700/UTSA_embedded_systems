#include <stdio.h>
#include <stdint.h>

#include "../../include/int_arithmetic.h"

extern int32_t int_multiply(int32_t num1, int32_t num2){
    return num1 * num2;
}