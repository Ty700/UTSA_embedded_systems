#include "../../include/double_arithmetic.hpp"

extern double double_subtract (double num1, double num2){
    return num1 - num2;
}