#include "../../include/double_arithmetic.hpp"

extern double double_division(double num1, double num2){
    return num1 / num2;
}